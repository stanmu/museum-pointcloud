import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "器物四观｜数字文物互动展",
  description: "四件三维器物的粒子序章、互动光影、来源依据、资料档案与关联事件展陈。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
  openGraph: {
    title: "器物四观｜数字文物互动展",
    description: "以可交互光影与粒子重构四件数字器物。",
    images: [{ url: "/og.png", width: 1678, height: 944 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "器物四观｜数字文物互动展",
    description: "四件数字器物的互动展陈系统。",
    images: ["/og.png"],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
