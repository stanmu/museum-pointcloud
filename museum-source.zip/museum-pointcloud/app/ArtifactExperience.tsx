"use client";
/* eslint-disable @next/next/no-img-element -- raw transparent model renders must bypass image optimisation */

import { useEffect, useRef, useState, type CSSProperties } from "react";
import * as THREE from "three";

const PAGES = ["序章", "光影鉴赏", "来源依据", "资料来源", "关联事件"];

type ArtifactCopy = {
  subtitle: string;
  tags: string[];
  fields: Array<[string, string]>;
  verification: string;
  summary: string;
  sources: Array<{ id: string; title: string; details: string; status: string }>;
  events: Array<{ time: string; title: string; source: string; status: string }>;
};

const COPY_BY_ID: Record<string, ArtifactCopy> = {
  "01": {
    subtitle: "福建博物院藏 · 国家一级文物",
    tags: ["脱胎漆器", "薄料", "印锦", "国家一级文物"],
    fields: [["规范名称", "近代沈正镐脱胎竹根瓶"], ["作者", "沈正镐"], ["年代", "近代"], ["尺寸", "通高113cm · 口径32.5cm · 底径38cm"], ["馆藏机构", "福建博物院"], ["藏品编号", "公开官方页面未公布"]],
    verification: "基础属性 A 级，可直接使用；藏品编号待馆方核实。",
    summary: "薄料、印锦工艺。瓶身呈竹节生长状，竹叶以印锦工艺压模，整体含金晕银色泽。论文表5-1列为非核心展品（仅做展示），使用官方馆藏图并纳入建模。",
    sources: [
      { id: "S03", title: "福建省文化和旅游厅｜八闽文物·巧夺天工", details: "省级文旅／文物专题；支撑基础属性、工艺、馆藏与国家一级文物信息。", status: "A · 直接使用" },
      { id: "S04", title: "央广网｜遇见世遗：沈绍安家族与福州脱胎漆器", details: "权威媒体历史资料；支撑沈氏后代向福建省博物馆捐赠竹根瓶的历史。", status: "B+ · 辅助使用" },
      { id: "S05", title: "中国国家博物馆｜格物匠心——福建传统工艺展", details: "国家级博物馆展览记录；支撑2020年参展信息。", status: "A · 直接使用" },
    ],
    events: [
      { time: "新中国成立初期", title: "沈氏后代捐赠福建省博物馆", source: "央广网记载《竹根瓶》等由沈正镐子女无偿献给福建省博物馆；具体年份未载。", status: "B+ · 建议馆方档案加固" },
      { time: "2020年", title: "参加“格物匠心——福建传统工艺展”", source: "中国国家博物馆官方专题将该器列为重要展品。", status: "A · 可进入展览事件" },
    ],
  },
  "02": {
    subtitle: "故宫博物院藏 · 藏品编号 故00115450",
    tags: ["清乾隆", "宫廷漆器", "菊瓣式", "脱胎工艺"],
    fields: [["规范名称", "脱胎朱漆菊瓣式盖碗"], ["作者", "未署作者（不宜写“沈绍安”）"], ["年代", "清乾隆（1776）"], ["尺寸", "口径10.8cm · 通高9.8cm"], ["馆藏机构", "故宫博物院"], ["藏品编号", "故00115450"]],
    verification: "证据分级：可直接使用；核验依据：器内缉纻芦苇痕与束带腰。",
    summary: "清乾隆时期漆器精品，以脱胎工艺制作。器形仿菊瓣展开，线条柔和，朱漆色泽沉稳温润；轻巧胎体与细腻漆面体现宫廷漆器精细繁复的制作技艺。",
    sources: [
      { id: "故00115450", title: "馆藏官网记录", details: "故宫博物院《脱胎朱漆菊瓣式盖碗》藏品页；支撑年代、尺寸、馆藏字段。", status: "A · 已核验" },
      { id: "DSC-0412", title: "现场展签（田野拍摄）", details: "广东省博物馆漆器展现场展签；用于器物表面状态与背景说明。", status: "辅助说明" },
      { id: "装饰-2017-08", title: "胡新池｜“夹纻胎”与“脱胎”辨析", details: "《装饰》2017(08)；文献互证，用于脱胎工艺背景解释。", status: "辅助说明" },
    ],
    events: [
      { time: "乾隆四十年（1775）", title: "命苏州织造承做", source: "依据：清宫造办处档案 · 已核验", status: "可直接使用" },
      { time: "乾隆四十一年（1776）", title: "器内御制诗题记", source: "依据：器身铭文“乾隆丙申春御题” · 实物观察核验", status: "可直接使用" },
      { time: "当代", title: "故宫博物院收藏", source: "依据：故宫博物院藏品页 · 馆藏比对", status: "可直接使用" },
      { time: "资料状态", title: "修复／展览事件", source: "当前资料不足，暂不展开；遵循资料不足即降级原则。", status: "暂不展开" },
    ],
  },
  "03": {
    subtitle: "福建博物院藏 · 国家一级文物",
    tags: ["脱胎漆器", "薄料漆拍敷", "荷叶造型", "国家一级文物"],
    fields: [["规范名称", "近代沈正镐脱胎荷叶瓶"], ["作者", "沈正镐"], ["年代", "近代（清末民初）"], ["尺寸", "通高98cm · 口径38cm · 底径54cm"], ["馆藏机构", "福建博物院"], ["藏品编号", "公开官方页面未公布"]],
    verification: "基础属性 A 级；年代保留 S03／S06 两来源；藏品编号待馆方核实。",
    summary: "薄料漆拍敷。主体青绿色，荷叶向上束拢、叶脉清晰，红荷、绿叶与莲蓬环绕底座，表面呈金属光泽。论文表5-1列为核心展品，图片由笔者拍摄并已纳入建模。",
    sources: [
      { id: "S03", title: "福建省文化和旅游厅｜八闽文物·巧夺天工", details: "支撑基础属性、工艺、馆藏及国家一级文物信息。", status: "A · 直接使用" },
      { id: "S04", title: "央广网｜遇见世遗：沈绍安家族与福州脱胎漆器", details: "支撑新中国成立初期沈氏后代捐赠史。", status: "B+ · 辅助使用" },
      { id: "S06", title: "中国纪检监察杂志｜莲韵廉心：文物里的清风正气", details: "支撑2025年“爱廉说”特展及“清末民初”年代表述。", status: "B+ · 辅助使用" },
    ],
    events: [
      { time: "新中国成立初期", title: "沈氏后代捐赠福建省博物馆", source: "央广网记载沈德铭、沈忠英将《荷叶瓶》等无偿献给福建省博物馆；具体年份未载。", status: "B+ · 建议馆方档案加固" },
      { time: "2025年", title: "参加“爱廉说——文物话清廉特展”", source: "中国纪检监察杂志的福建博物院专题展报道直接展示该器。", status: "B+ · 可进入展览事件" },
    ],
  },
  "04": {
    subtitle: "福建博物院藏 · 国家一级文物",
    tags: ["脱胎造像", "薄料", "揩清", "古铜色泽"],
    fields: [["规范名称", "近代沈正镐脱胎提篮观音"], ["作者", "沈正镐"], ["年代", "近代"], ["尺寸", "通高75.5cm · 底径37cm"], ["馆藏机构", "福建博物院"], ["藏品编号", "公开官方页面未公布"]],
    verification: "基础属性 A 级，可直接使用；藏品编号待馆方核实。",
    summary: "薄料、揩清工艺，呈古铜色泽。观音高髻、手提鱼篮，跣足立于浪花翻卷的荷花座上。论文表5-1列为核心展品，使用官方馆藏图并纳入建模。",
    sources: [
      { id: "S03", title: "福建省文化和旅游厅｜八闽文物·巧夺天工", details: "支撑现行规范名称、作者、尺寸、馆藏、工艺及国家一级文物信息。", status: "A · 直接使用" },
      { id: "S04", title: "央广网｜遇见世遗：沈绍安家族与福州脱胎漆器", details: "提供“提篮仙女”捐赠史线索；与现行“提篮观音”名称的同一性仍待馆方档案确认。", status: "B+ · 线索使用" },
    ],
    events: [
      { time: "新中国成立初期", title: "“三宝”捐赠历史线索", source: "央广网称捐赠对象为《提篮仙女》，福建省文旅厅现行名称为《提篮观音》；无馆方入藏档案前不直接等同。", status: "B · 关联线索" },
    ],
  },
};

const ARTIFACTS = [
  {
    id: "01",
    name: "近代沈正镐脱胎竹根瓶",
    shortName: "脱胎竹根瓶",
    english: "LACQUER BAMBOO-ROOT VASE",
    file: "./artifact-01.bin",
    surface: "./artifact-01-surface.bin",
    material: { metalness: 0.0, roughness: 0.3, clearcoat: 0.52, clearcoatRoughness: 0.28 },
    displayScale: 0.96,
    model: "Meshy_AI_上_0404130030",
    accent: "#c49345",
    intro: "竹节含生 · 金晕银辉",
  },
  {
    id: "02",
    name: "脱胎朱漆菊瓣式盖碗",
    shortName: "朱漆菊瓣盖碗",
    english: "VERMILION LACQUER CHRYSANTHEMUM BOWL",
    file: "./artifact-02.bin",
    surface: "./artifact-02-surface.bin",
    material: { metalness: 0.0, roughness: 0.34, clearcoat: 0.3, clearcoatRoughness: 0.36 },
    displayScale: 0.78,
    model: "Meshy_AI_Red_Ribbed_Ginger_Jar_0404105839",
    accent: "#bd4933",
    intro: "朱火含光 · 弦纹成韵",
  },
  {
    id: "03",
    name: "近代沈正镐脱胎荷叶瓶",
    shortName: "脱胎荷叶瓶",
    english: "LACQUER LOTUS-LEAF VASE",
    file: "./artifact-03.bin",
    surface: "./artifact-03-surface.bin",
    material: { metalness: 0.0, roughness: 0.25, clearcoat: 0.72, clearcoatRoughness: 0.2 },
    displayScale: 0.92,
    model: "Meshy_AI_Emerald_Lotus_Vase_0404125752",
    accent: "#6fa66c",
    intro: "莲影入器 · 翠色生光",
  },
  {
    id: "04",
    name: "近代沈正镐脱胎提篮观音",
    shortName: "脱胎提篮观音",
    english: "LACQUER BASKET-BEARING GUANYIN",
    file: "./artifact-04.bin",
    surface: "./artifact-04-surface.bin",
    material: { metalness: 0.0, roughness: 0.43, clearcoat: 0.16, clearcoatRoughness: 0.5 },
    displayScale: 0.9,
    model: "Meshy_AI_0_0404125959",
    accent: "#b27a48",
    intro: "古铜含光 · 慈容静立",
  },
];

const vertexShader = /* glsl */ `
  attribute float aSeed;
  attribute vec3 aNormal;
  uniform float uTime;
  uniform float uIntro;
  uniform float uPixelRatio;
  uniform float uLightIntensity;
  uniform float uYaw;
  uniform float uPitch;
  uniform float uScale;
  uniform float uOpacity;
  uniform float uParticles;
  uniform vec2 uOffset;
  uniform vec3 uLightDir;
  varying vec3 vColor;
  varying float vAlpha;

  float hash(float n) { return fract(sin(n) * 43758.5453123); }
  float ease(float x) { return x * x * (3.0 - 2.0 * x); }

  void main() {
    float seedB = hash(aSeed * 97.13 + 4.7);
    float seedC = hash(aSeed * 241.71 + 8.1);
    float gather = ease(smoothstep(0.04 + aSeed * 0.18, 0.46, uIntro));
    float persistentSilhouette = step(0.28, aSeed);
    float assemble = mix(1.0, max(persistentSilhouette, gather), step(0.001, uIntro));
    vec3 origin = vec3((seedB - 0.5) * 8.2, -3.4 + seedC * 1.2, (hash(aSeed * 411.0) - 0.5) * 4.0);
    vec3 p = mix(origin, position, assemble);

    float cy = cos(uYaw);
    float sy = sin(uYaw);
    float cp = cos(uPitch);
    float sp = sin(uPitch);
    mat3 rotateY = mat3(cy, 0.0, -sy, 0.0, 1.0, 0.0, sy, 0.0, cy);
    mat3 rotateX = mat3(1.0, 0.0, 0.0, 0.0, cp, sp, 0.0, -sp, cp);
    mat3 artifactRotation = rotateY * rotateX;
    p = artifactRotation * p * uScale;
    vec3 surfaceNormal = normalize(artifactRotation * aNormal);

    float diffuse = max(dot(surfaceNormal, normalize(uLightDir)), 0.0);
    float backLight = pow(max(dot(-surfaceNormal, normalize(uLightDir)), 0.0), 3.0);
    float spark = step(0.956, aSeed) * uParticles * assemble;
    float life = fract(uTime * (0.12 + seedB * 0.09) + seedC * 4.0);
    vec3 drift = normalize(uLightDir + vec3(0.0, 0.62, 0.0));
    p += spark * drift * life * (0.32 + uLightIntensity * 0.35);
    p.x += spark * sin(uTime * 2.0 + aSeed * 91.0) * 0.08;
    p.xy += uOffset;

    vec4 mvPosition = modelViewMatrix * vec4(p, 1.0);
    gl_Position = projectionMatrix * mvPosition;
    float shimmer = 0.78 + 0.32 * sin(uTime * 1.7 + aSeed * 56.0);
    float sparkSize = 1.0 + spark * (2.0 + life * 2.4);
    gl_PointSize = (0.92 + seedB * 1.1) * shimmer * sparkSize * uPixelRatio * (8.0 / -mvPosition.z);

    vec3 warmLight = vec3(1.0, 0.72, 0.38);
    float illumination = 0.16 + diffuse * (0.43 + uLightIntensity * 0.72);
    vec3 highlight = warmLight * pow(diffuse, 4.0) * uLightIntensity * 0.32;
    vec3 edgeGlow = vec3(0.20, 0.61, 0.45) * backLight * uLightIntensity * 0.18;
    vColor = color * illumination + highlight + edgeGlow + spark * warmLight * (0.42 + life * 0.52);
    vAlpha = assemble * uOpacity * (0.34 + seedB * 0.25 + diffuse * 0.24);
    vAlpha += spark * (1.0 - life) * 0.42;
  }
`;

const fragmentShader = /* glsl */ `
  varying vec3 vColor;
  varying float vAlpha;
  void main() {
    float d = length(gl_PointCoord - vec2(0.5));
    float core = 1.0 - smoothstep(0.08, 0.5, d);
    float halo = 1.0 - smoothstep(0.20, 0.5, d);
    float alpha = (core * 0.78 + halo * 0.22) * vAlpha;
    if (alpha < 0.015) discard;
    gl_FragColor = vec4(vColor, alpha);
  }
`;

export default function ArtifactExperience() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLElement>(null);
  const pageRef = useRef(0);
  const lightTargetRef = useRef({ x: 0.35, y: 0.5, intensity: 1.05 });
  const rotationTargetRef = useRef({ yaw: 0, pitch: 0 });
  const loadProjectRef = useRef<(index: number) => void>(() => undefined);
  const [activeProject, setActiveProject] = useState(0);
  const [activePage, setActivePage] = useState(0);
  const [ready, setReady] = useState(false);
  const [evidenceOpen, setEvidenceOpen] = useState(false);
  const [useSafariFallback, setUseSafariFallback] = useState(false);
  const [surfaceReady, setSurfaceReady] = useState(false);
  const artifact = ARTIFACTS[activeProject];
  const copy = COPY_BY_ID[artifact.id];

  const changePage = (next: number) => {
    const normalized = (next + PAGES.length) % PAGES.length;
    pageRef.current = normalized;
    setActivePage(normalized);
    setEvidenceOpen(false);
  };

  const changeProject = (index: number) => {
    setReady(false);
    setActiveProject(index);
    pageRef.current = 0;
    setActivePage(0);
    setEvidenceOpen(false);
    setSurfaceReady(false);
    rotationTargetRef.current = { yaw: 0, pitch: 0 };
    loadProjectRef.current(index);
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "ArrowRight") changePage(pageRef.current + 1);
      if (event.key === "ArrowLeft") changePage(pageRef.current - 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const stage = stageRef.current;
    if (!canvas || !stage) return;

    // Safari can create a WebGL context yet silently render an empty points canvas
    // on some macOS/GPU combinations. Keep the interaction model, but guarantee a
    // visible particle silhouette through a transparent, light-reactive fallback.
    const safari = /^((?!chrome|chromium|android).)*safari/i.test(navigator.userAgent);
    const forceFallback = new URLSearchParams(window.location.search).has("fallback");
    setUseSafariFallback(safari || forceFallback);

    let disposed = false;
    let frame = 0;
    let previous = performance.now();
    let introElapsed = 0;
    let dragging = false;
    let dragX = 0;
    let dragY = 0;
    let surfaceYaw = 0;
    let surfacePitch = 0;
    let currentProjectIndex = 0;
    let lightIntensity = 1.05;
    let artifactGeometry: THREE.BufferGeometry | null = null;
    let artifactMaterial: THREE.ShaderMaterial | null = null;
    let points: THREE.Points | null = null;
    let surfaceGeometry: THREE.BufferGeometry | null = null;
    let surfaceMaterial: THREE.MeshPhysicalMaterial | null = null;
    let surfaceBackfillMaterial: THREE.MeshPhysicalMaterial | null = null;
    let surfaceMesh: THREE.Mesh | null = null;
    let requestToken = 0;
    let surfaceRequestToken = 0;

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: "high-performance" });
    renderer.setClearColor(0x020705, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x06100c, 0.052);
    const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 60);
    camera.position.set(0, 0.05, 7.4);
    const hemisphereLight = new THREE.HemisphereLight(0xd8c7a5, 0x04100b, 1.25);
    const keyLight = new THREE.DirectionalLight(0xffd4a0, 4.4);
    const rimLight = new THREE.DirectionalLight(0x4eae86, 1.45);
    keyLight.position.set(2.2, 3.0, 5.0);
    rimLight.position.set(-3.2, 1.2, -2.5);
    scene.add(hemisphereLight, keyLight, rimLight);

    const lightDirection = new THREE.Vector3(0.35, 0.5, 1).normalize();
    const lightDirectionTarget = lightDirection.clone();
    const offset = new THREE.Vector2(1.45, -0.03);
    const offsetTarget = offset.clone();
    const uniforms = {
      uTime: { value: 0 },
      uIntro: { value: 0.001 },
      uPixelRatio: { value: 1 },
      uLightIntensity: { value: 1.05 },
      uYaw: { value: 0 },
      uPitch: { value: 0 },
      uScale: { value: 1 },
      uOpacity: { value: 1 },
      uParticles: { value: 1 },
      uOffset: { value: offset },
      uLightDir: { value: lightDirection },
    };

    const mountainGeometry = new THREE.BufferGeometry();
    const mountainCount = 14_000;
    const mountainPositions = new Float32Array(mountainCount * 3);
    const mountainColors = new Float32Array(mountainCount * 3);
    for (let i = 0; i < mountainCount; i += 1) {
      const x = (Math.random() - 0.5) * 17;
      const depth = -2.8 - Math.random() * 7.5;
      const ridge = Math.abs(Math.sin(x * 0.56 + depth * 0.13)) * 1.4 + Math.abs(Math.sin(x * 1.28 - depth * 0.18)) * 0.42;
      mountainPositions.set([x, -2.43 + ridge * (0.28 + Math.random() * 0.72), depth], i * 3);
      mountainColors.set(Math.random() > 0.58 ? [0.53, 0.36, 0.14] : [0.08, 0.27, 0.20], i * 3);
    }
    mountainGeometry.setAttribute("position", new THREE.BufferAttribute(mountainPositions, 3));
    mountainGeometry.setAttribute("color", new THREE.BufferAttribute(mountainColors, 3));
    const mountainMaterial = new THREE.PointsMaterial({ size: 0.021, vertexColors: true, transparent: true, opacity: 0.5, depthWrite: false, blending: THREE.AdditiveBlending });
    const mountains = new THREE.Points(mountainGeometry, mountainMaterial);
    scene.add(mountains);

    const disposeArtifact = () => {
      if (points) scene.remove(points);
      artifactGeometry?.dispose();
      artifactMaterial?.dispose();
      points = null;
      artifactGeometry = null;
      artifactMaterial = null;
    };

    const disposeSurface = () => {
      if (surfaceMesh) scene.remove(surfaceMesh);
      surfaceGeometry?.dispose();
      surfaceMaterial?.dispose();
      surfaceBackfillMaterial?.dispose();
      surfaceMesh = null;
      surfaceGeometry = null;
      surfaceMaterial = null;
      surfaceBackfillMaterial = null;
    };

    const loadArtifact = (index: number) => {
      const token = ++requestToken;
      fetch(ARTIFACTS[index].file)
        .then((response) => {
          if (!response.ok) throw new Error("Unable to load artifact data");
          return response.arrayBuffer();
        })
        .then((buffer) => {
          if (disposed || token !== requestToken) return;
          const source = new Float32Array(buffer);
          const count = source.length / 10;
          const positions = new Float32Array(count * 3);
          const colors = new Float32Array(count * 3);
          const normals = new Float32Array(count * 3);
          const seeds = new Float32Array(count);
          for (let i = 0; i < count; i += 1) {
            const sourceIndex = i * 10;
            positions.set(source.subarray(sourceIndex, sourceIndex + 3), i * 3);
            colors.set(source.subarray(sourceIndex + 3, sourceIndex + 6), i * 3);
            normals.set(source.subarray(sourceIndex + 6, sourceIndex + 9), i * 3);
            seeds[i] = source[sourceIndex + 9];
          }
          disposeArtifact();
          artifactGeometry = new THREE.BufferGeometry();
          artifactGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
          artifactGeometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
          artifactGeometry.setAttribute("aNormal", new THREE.BufferAttribute(normals, 3));
          artifactGeometry.setAttribute("aSeed", new THREE.BufferAttribute(seeds, 1));
          artifactMaterial = new THREE.ShaderMaterial({ uniforms, vertexShader, fragmentShader, transparent: true, depthWrite: false, vertexColors: true, blending: THREE.AdditiveBlending });
          points = new THREE.Points(artifactGeometry, artifactMaterial);
          scene.add(points);
          introElapsed = 0;
          setReady(true);
        })
        .catch(() => setReady(true));
    };

    const loadSurface = (index: number) => {
      const token = ++surfaceRequestToken;
      setSurfaceReady(false);
      fetch(ARTIFACTS[index].surface)
        .then((response) => {
          if (!response.ok) throw new Error("Unable to load surface mesh");
          return response.arrayBuffer();
        })
        .then((buffer) => {
          if (disposed || token !== surfaceRequestToken) return;
          const view = new DataView(buffer);
          const magic = String.fromCharCode(view.getUint8(0), view.getUint8(1), view.getUint8(2), view.getUint8(3));
          if (magic !== "MSH1") throw new Error("Invalid surface mesh");
          const vertexCount = view.getUint32(4, true);
          const triangleCount = view.getUint32(8, true);
          let byteOffset = 12;
          const positions = new Float32Array(buffer, byteOffset, vertexCount * 3);
          byteOffset += vertexCount * 3 * 4;
          const normals = new Float32Array(buffer, byteOffset, vertexCount * 3);
          byteOffset += vertexCount * 3 * 4;
          const colors = new Float32Array(buffer, byteOffset, vertexCount * 3);
          byteOffset += vertexCount * 3 * 4;
          const indices = new Uint32Array(buffer, byteOffset, triangleCount * 3);

          disposeSurface();
          surfaceGeometry = new THREE.BufferGeometry();
          surfaceGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
          surfaceGeometry.setAttribute("normal", new THREE.BufferAttribute(normals, 3));
          surfaceGeometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
          surfaceGeometry.setIndex(new THREE.BufferAttribute(indices, 1));
          surfaceGeometry.computeBoundingSphere();
          surfaceMaterial = new THREE.MeshPhysicalMaterial({
            ...ARTIFACTS[index].material,
            vertexColors: true,
            side: THREE.DoubleSide,
            sheen: index === 1 ? 0.16 : 0.05,
            sheenColor: new THREE.Color(index === 1 ? 0x7f120b : 0x5a3317),
          });
          surfaceMesh = new THREE.Mesh(surfaceGeometry, surfaceMaterial);
          surfaceBackfillMaterial = surfaceMaterial.clone();
          surfaceBackfillMaterial.roughness = Math.min(1, surfaceMaterial.roughness + 0.16);
          [
            { scale: 0.991, rotation: [0.004, -0.007, 0.003] },
            { scale: 0.979, rotation: [-0.008, 0.012, -0.004] },
            { scale: 0.964, rotation: [0.011, -0.016, 0.006] },
          ].forEach(({ scale, rotation }) => {
            const surfaceBackfill = new THREE.Mesh(surfaceGeometry, surfaceBackfillMaterial!);
            surfaceBackfill.scale.setScalar(scale);
            surfaceBackfill.rotation.set(rotation[0], rotation[1], rotation[2]);
            surfaceBackfill.renderOrder = -1;
            surfaceMesh!.add(surfaceBackfill);
          });
          surfaceMesh.castShadow = false;
          surfaceMesh.receiveShadow = false;
          surfaceMesh.visible = pageRef.current === 1 || pageRef.current === 2;
          scene.add(surfaceMesh);
          setSurfaceReady(true);
        })
        .catch(() => setSurfaceReady(false));
    };

    loadProjectRef.current = (index: number) => {
      currentProjectIndex = index;
      loadArtifact(index);
      loadSurface(index);
    };
    loadProjectRef.current(0);

    const updateReadout = (x: number, y: number, intensity: number) => {
      stage.style.setProperty("--fallback-light-x", `${50 + x * 36}%`);
      stage.style.setProperty("--fallback-light-y", `${50 - y * 36}%`);
      stage.style.setProperty("--fallback-light-power", `${0.72 + intensity * 0.38}`);
    };

    const onPointerMove = (event: PointerEvent) => {
      if (pageRef.current !== 1 && pageRef.current !== 2) return;
      if (dragging) {
        const deltaX = event.clientX - dragX;
        const deltaY = event.clientY - dragY;
        dragX = event.clientX;
        dragY = event.clientY;
        rotationTargetRef.current.yaw += deltaX * 0.009;
        rotationTargetRef.current.pitch = THREE.MathUtils.clamp(rotationTargetRef.current.pitch + deltaY * 0.006, -0.48, 0.48);
        stage.style.setProperty("--rotation-yaw", rotationTargetRef.current.yaw.toFixed(3));
        stage.style.setProperty("--fallback-turn", `${Math.max(0.42, Math.abs(Math.cos(rotationTargetRef.current.yaw)))}`);
        stage.style.setProperty("--fallback-skew", `${Math.sin(rotationTargetRef.current.yaw) * -5}deg`);
        return;
      }
      const rect = canvas.getBoundingClientRect();
      const x = Math.max(-1, Math.min(1, ((event.clientX - rect.left) / rect.width - 0.5) * 2));
      const y = Math.max(-1, Math.min(1, -((event.clientY - rect.top) / rect.height - 0.5) * 2));
      lightTargetRef.current.x = x * 1.25;
      lightTargetRef.current.y = y * 0.95;
      updateReadout(lightTargetRef.current.x / 1.25, lightTargetRef.current.y / 0.95, lightTargetRef.current.intensity);
    };
    const onPointerDown = (event: PointerEvent) => {
      if (pageRef.current !== 1 && pageRef.current !== 2) return;
      dragging = true;
      dragX = event.clientX;
      dragY = event.clientY;
      canvas.setPointerCapture(event.pointerId);
      canvas.classList.add("is-dragging");
    };
    const onPointerUp = (event: PointerEvent) => {
      dragging = false;
      if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
      canvas.classList.remove("is-dragging");
    };
    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointerup", onPointerUp);
    canvas.addEventListener("pointercancel", onPointerUp);

    const resize = () => {
      const width = stage.clientWidth;
      const height = stage.clientHeight;
      const ratio = Math.min(window.devicePixelRatio, 1.6);
      renderer.setPixelRatio(ratio);
      renderer.setSize(width, height, false);
      camera.aspect = width / Math.max(height, 1);
      camera.updateProjectionMatrix();
      uniforms.uPixelRatio.value = ratio;
    };
    resize();
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(stage);

    const animate = (now: number) => {
      const delta = Math.min(now - previous, 80);
      previous = now;
      const page = pageRef.current;
      introElapsed += delta;
      const introPhase = page === 0 ? Math.min(0.08 + introElapsed / 3600, 1) : 0;
      const layoutTargets = [
        { x: 1.48, y: -0.02, scale: 1.0, opacity: 1.0, particles: 1.0 },
        { x: -0.15, y: -0.03, scale: 1.08, opacity: 1.0, particles: 0.55 },
        { x: -1.62, y: -0.04, scale: 0.92, opacity: 0.95, particles: 0.18 },
        { x: 2.35, y: -0.05, scale: 0.82, opacity: 0.15, particles: 0.05 },
        { x: 2.35, y: -0.05, scale: 0.82, opacity: 0.13, particles: 0.05 },
      ][page];
      offsetTarget.set(layoutTargets.x, layoutTargets.y);
      offset.lerp(offsetTarget, 0.065);
      lightDirectionTarget.set(lightTargetRef.current.x, lightTargetRef.current.y, 1).normalize();
      lightDirection.lerp(lightDirectionTarget, 0.075).normalize();
      lightIntensity += (lightTargetRef.current.intensity - lightIntensity) * 0.075;
      uniforms.uTime.value = now / 1000;
      uniforms.uIntro.value = introPhase;
      uniforms.uLightIntensity.value = lightIntensity;
      uniforms.uYaw.value = page === 0 ? Math.sin(now * 0.00016) * 0.12 : 0;
      uniforms.uPitch.value = 0;
      uniforms.uScale.value += (layoutTargets.scale - uniforms.uScale.value) * 0.065;
      uniforms.uOpacity.value += (layoutTargets.opacity - uniforms.uOpacity.value) * 0.065;
      uniforms.uParticles.value += (layoutTargets.particles - uniforms.uParticles.value) * 0.065;
      if (points) points.visible = page === 0;
      surfaceYaw += (rotationTargetRef.current.yaw - surfaceYaw) * 0.14;
      surfacePitch += (rotationTargetRef.current.pitch - surfacePitch) * 0.14;
      if (surfaceMesh) {
        surfaceMesh.visible = page === 1 || page === 2;
        surfaceMesh.rotation.set(surfacePitch, surfaceYaw, 0);
        surfaceMesh.position.x += ((page === 2 ? -1.62 : -0.02) - surfaceMesh.position.x) * 0.09;
        surfaceMesh.position.y += (-0.05 - surfaceMesh.position.y) * 0.09;
        const surfaceScale = (page === 2 ? 0.92 : 1.08) * ARTIFACTS[currentProjectIndex].displayScale;
        surfaceMesh.scale.lerp(new THREE.Vector3(surfaceScale, surfaceScale, surfaceScale), 0.09);
      }
      keyLight.position.set(lightDirection.x * 5.2, lightDirection.y * 5.2, 4.2);
      keyLight.intensity = 2.7 + lightIntensity * 1.75;
      mountains.visible = page === 0;
      mountains.rotation.y = Math.sin(now * 0.000035) * 0.025;
      renderer.render(scene, camera);
      frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);

    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      canvas.removeEventListener("pointermove", onPointerMove);
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointerup", onPointerUp);
      canvas.removeEventListener("pointercancel", onPointerUp);
      disposeArtifact();
      disposeSurface();
      mountainGeometry.dispose();
      mountainMaterial.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <main className={`artifact-shell page-${activePage + 1} ${useSafariFallback ? "has-render-fallback" : ""} ${surfaceReady ? "surface-ready" : ""}`} ref={stageRef} style={{ "--accent": artifact.accent } as CSSProperties}>
      <div className="exhibition-backdrop" aria-hidden="true" />
      <canvas ref={canvasRef} className="artifact-canvas" aria-label={`${artifact.name}可交互器物展示`} />
      <div className="artifact-fallback" aria-hidden="true">
        <div className="fallback-object fallback-particle-object">
          <img className="fallback-model fallback-base" src={`./artifact-${artifact.id}-fallback.png`} alt="" draggable={false} />
          <img className="fallback-model fallback-highlight" src={`./artifact-${artifact.id}-fallback.png`} alt="" draggable={false} />
        </div>
        <div className="fallback-approved-plate">
          <img src={`./artifact-${artifact.id}-approved.png`} alt="" draggable={false} />
        </div>
      </div>
      <div className="mist-layer" aria-hidden="true" />
      <div className="grain-layer" aria-hidden="true" />

      <header className="site-header">
        <a className="brand" href="#top" onClick={() => changePage(0)}>
          <span className="brand-mark">山</span>
          <span>数字文物研究室<small>DIGITAL RELIC LAB</small></span>
        </a>
        <nav aria-label="文物页面导航">
          {PAGES.map((label, index) => (
            <button key={label} className={activePage === index ? "active" : ""} onClick={() => changePage(index)}>
              <span>0{index + 1}</span>{label}
            </button>
          ))}
        </nav>
        <label className="project-select">
          <span>COLLECTION</span>
          <select value={activeProject} onChange={(event) => changeProject(Number(event.target.value))} aria-label="选择文物项目">
            {ARTIFACTS.map((item, index) => <option value={index} key={item.id}>{item.id} · {item.shortName}</option>)}
          </select>
        </label>
      </header>

      <section className={`page-layer intro-page ${activePage === 0 ? "is-active" : ""}`} id="top">
        <p className="page-eyebrow">DIGITAL ARTIFACT STUDY <span>·</span> PROJECT {artifact.id}</p>
        <p className="intro-kicker">{artifact.intro}</p>
        <h1>{artifact.name}</h1>
        <p className="english-title">{artifact.english}</p>
        <div className="intro-meta"><span>数字展陈概念研究</span><span>表面采样 120,000</span><span>源模型 {artifact.id}</span></div>
      </section>

      <section className={`page-layer lighting-page ${activePage === 1 ? "is-active" : ""}`}>
        <div className="section-heading">
          <span>LIGHT STUDY / 02</span>
          <h2>光影<br />鉴赏</h2>
          <p>移动鼠标改变光线方向；按住器物拖拽旋转，查看纹饰、起伏与材质细节。</p>
        </div>
        <div className="light-follow-hint"><i />移动照明 · 拖拽旋转<span>MOVE LIGHT · DRAG TO ROTATE</span></div>
      </section>

      <section className={`page-layer evidence-page ${activePage === 2 ? "is-active" : ""}`}>
        <div className="model-caption"><span>MODEL / {artifact.id}</span><strong>{artifact.shortName}</strong><p>实体表面展示 · 移动照明，按住拖拽旋转器物。</p></div>
        <article className={`evidence-card ${evidenceOpen ? "is-open" : ""}`}>
          {!evidenceOpen ? (
            <button className="reveal-evidence" onClick={() => setEvidenceOpen(true)}>
              <span className="reveal-icon">＋</span>
              <span className="reveal-copy"><small>ARCHIVE · 03</small><b>展开器物档案</b><em>查看来源依据与核验记录</em></span>
              <span className="reveal-arrow">→</span>
            </button>
          ) : (
            <div className="evidence-content">
              <div className="card-heading"><span>OBJECT ARCHIVE / {artifact.id}</span><button onClick={() => setEvidenceOpen(false)} aria-label="收起来源依据">×</button></div>
              <div className="artifact-tags">{copy.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
              <h2>{artifact.name}</h2>
              <p className="placeholder-note">{copy.subtitle}</p>
              <dl>{copy.fields.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>
              <div className="source-overview"><b>来源综述</b><p>{copy.summary}</p></div>
              <p className="verification-note">{copy.verification}</p>
            </div>
          )}
        </article>
      </section>

      <section className={`page-layer archive-page ${activePage === 3 ? "is-active" : ""}`}>
        <div className="archive-heading"><span>ARCHIVE / 04</span><h2>资料来源</h2><p>展示结论 ↔ 原始依据；每条资料对应独立证据记录。</p></div>
        <div className="archive-list is-detailed">
          {copy.sources.map((item) => (
            <article key={item.id}><b>{item.id}</b><div><h3>{item.title}</h3><p>{item.details}</p></div><span>{item.status}</span></article>
          ))}
        </div>
        <p className="source-footnote">每一张资料卡片对应第四章证据台账的一个 claim_id / source_id</p>
      </section>

      <section className={`page-layer events-page ${activePage === 4 ? "is-active" : ""}`}>
        <div className="archive-heading"><span>CONTEXT / 05</span><h2>关联事件</h2><p>时间性信息 → 事件节点；仅展示已经核验或明确降级的事项。</p></div>
        <div className="event-line" style={{ "--event-count": copy.events.length } as CSSProperties}>
          {copy.events.map((item) => (
            <article key={`${item.time}-${item.title}`}><span className="event-dot" /><time>{item.time}</time><h3>{item.title}</h3><p>{item.source}</p><span className="event-status">{item.status}</span></article>
          ))}
        </div>
      </section>

      <button className="page-arrow prev" onClick={() => changePage(activePage - 1)} aria-label="上一页"><span>‹</span><small>上一页</small></button>
      <button className="page-arrow next" onClick={() => changePage(activePage + 1)} aria-label="下一页"><small>下一页</small><span>›</span></button>

      <footer className="experience-footer">
        <div className="artifact-index"><span>ARTIFACT</span><strong>{artifact.id}</strong><i>/ 04</i></div>
        <div className="page-progress">{PAGES.map((label, index) => <button key={label} className={activePage === index ? "active" : ""} onClick={() => changePage(index)} aria-label={`转到${label}`}><span /></button>)}</div>
        <div className="page-count"><span>PAGE</span><strong>0{activePage + 1}</strong><i>/ 05</i></div>
      </footer>

      <div className={`loading-screen ${ready ? "is-ready" : ""}`} role="status"><span className="loading-seal">器</span><p>正在载入 {artifact.shortName}</p></div>
      <div className="edge-label left">数字文物 · 非实物鉴定</div>
      <div className="edge-label right">{activePage < 3 ? "MOVE LIGHT / DRAG TO ROTATE" : "DIGITAL ARCHIVE / RESEARCH PLACEHOLDER"}</div>
    </main>
  );
}
