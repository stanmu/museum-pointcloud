import ArtifactExperience from "./ArtifactExperience";

export default function Home() {
  return <ArtifactExperience />;
}
