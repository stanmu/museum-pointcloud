import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import ArtifactExperience from "../app/ArtifactExperience";
import "../app/globals.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ArtifactExperience />
  </StrictMode>,
);
