@echo off
setlocal
cd /d "%~dp0"
title Digital Artifact Site - Windows Deployment
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0DEPLOY_WINDOWS.ps1"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%EXIT_CODE%"=="0" echo Deployment failed. Please keep this window and capture the complete error message.
pause
exit /b %EXIT_CODE%
