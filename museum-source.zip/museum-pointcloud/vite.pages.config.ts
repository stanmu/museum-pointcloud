import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// Relative URLs support both GitHub project sites and custom domains.
export default defineConfig({
  base: "./",
  plugins: [react()],
  build: { outDir: "pages-dist", emptyOutDir: true },
});
