@echo off
setlocal
title Digital Artifact Site - Stop
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$connections=Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue; if(-not $connections){Write-Host 'No website service is running on port 3000.'; exit 0}; $stopped=$false; $connections | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object { $id=$_; $process=Get-CimInstance Win32_Process -Filter ('ProcessId=' + $id) -ErrorAction SilentlyContinue; if($process.CommandLine -match 'vinext|museum-pointcloud'){Write-Host ('Stopping website process ' + $id); Stop-Process -Id $id -Force; $stopped=$true}else{Write-Host ('Port 3000 belongs to another program. Process ' + $id + ' was not stopped.')}}; if($stopped){Write-Host 'Website service stopped.'}"
echo.
pause
