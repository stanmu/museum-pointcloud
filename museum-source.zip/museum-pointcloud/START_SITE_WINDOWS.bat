@echo off
setlocal
cd /d "%~dp0"
title Digital Artifact Site - Start
set "SITE_URL=http://localhost:3000/"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri '%SITE_URL%' -TimeoutSec 2; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 (
  start "" "%SITE_URL%"
  exit /b 0
)

where node >nul 2>nul
if errorlevel 1 goto :not_deployed
where pnpm >nul 2>nul
if errorlevel 1 goto :not_deployed
if not exist "%~dp0dist\" goto :not_deployed

start "Digital Artifact Site Service - KEEP OPEN" cmd /k "call pnpm start"

for /L %%N in (1,1,60) do (
  timeout /t 1 /nobreak >nul
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri '%SITE_URL%' -TimeoutSec 2; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
  if not errorlevel 1 (
    start "" "%SITE_URL%"
    exit /b 0
  )
)

echo Startup timed out. Check the service window for the actual error.
pause
exit /b 1

:not_deployed
echo This computer has not completed production deployment.
echo Run DEPLOY_WINDOWS.bat first.
pause
exit /b 1
