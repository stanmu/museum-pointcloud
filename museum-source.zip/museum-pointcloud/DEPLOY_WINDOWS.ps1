[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SiteUrl = "http://localhost:3000/"
$MinimumNode = [version]"22.13.0"
$BuildLog = Join-Path $ProjectDir "windows-build.log"

function Write-Step([string]$Message) {
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Refresh-ProcessPath {
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath;$env:ProgramFiles\nodejs;$env:APPDATA\npm"
}

function Test-Site {
    try {
        $response = Invoke-WebRequest -UseBasicParsing -Uri $SiteUrl -TimeoutSec 2
        return $response.StatusCode -eq 200
    } catch {
        return $false
    }
}

function Get-NodeVersion {
    $raw = (& node --version 2>$null)
    if (-not $raw) { return $null }
    return [version]($raw.Trim().TrimStart("v"))
}

Set-Location $ProjectDir
Write-Host "============================================"
Write-Host " Digital Artifact Site - Windows Deployment"
Write-Host "============================================"

if (Test-Site) {
    Write-Host "The site is already running: $SiteUrl" -ForegroundColor Green
    Start-Process $SiteUrl
    exit 0
}

Refresh-ProcessPath
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodeCommand) {
    Write-Step "Installing Node.js LTS"
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget) {
        Start-Process "https://nodejs.org/en/download"
        throw "winget is unavailable. Install Node.js LTS from the opened page, then run DEPLOY_WINDOWS.bat again."
    }

    & winget install --id OpenJS.NodeJS.LTS -e --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { throw "Node.js installation failed with code $LASTEXITCODE." }
    Refresh-ProcessPath
}

$nodeVersion = Get-NodeVersion
if (-not $nodeVersion) { throw "Node.js is installed but is not visible to this process. Close the window and run DEPLOY_WINDOWS.bat again." }
if ($nodeVersion -lt $MinimumNode) {
    throw "Node.js $nodeVersion is too old. Install Node.js $MinimumNode or later."
}
Write-Host "Node.js $nodeVersion is ready." -ForegroundColor Green

if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
    Write-Step "Installing pnpm"
    & npm.cmd install --global pnpm
    if ($LASTEXITCODE -ne 0) { throw "pnpm installation failed with code $LASTEXITCODE." }
    Refresh-ProcessPath
}

$pnpmVersion = (& pnpm.cmd --version).Trim()
Write-Host "pnpm $pnpmVersion is ready." -ForegroundColor Green

if (-not (Test-Path (Join-Path $ProjectDir "package.json"))) {
    throw "package.json is missing. Run this file inside the complete deployment folder."
}
if (-not (Test-Path (Join-Path $ProjectDir "pnpm-lock.yaml"))) {
    throw "pnpm-lock.yaml is missing. Re-extract the complete deployment package."
}

# The build configuration reads this local Sites metadata file. Older slim
# Windows packages accidentally omitted it, so recreate the no-database default
# when it is absent.
$hostingDir = Join-Path $ProjectDir ".openai"
$hostingFile = Join-Path $hostingDir "hosting.json"
if (-not (Test-Path $hostingFile)) {
    Write-Step "Repairing missing local build metadata"
    New-Item -ItemType Directory -Path $hostingDir -Force | Out-Null
    [System.IO.File]::WriteAllText($hostingFile, "{`n  `"d1`": null,`n  `"r2`": null`n}", [System.Text.UTF8Encoding]::new($false))
}

Write-Step "Installing Windows dependencies"
& pnpm.cmd install --frozen-lockfile
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed with code $LASTEXITCODE." }

Write-Step "Building the production website"
Write-Host "Complete build output is also saved to: $BuildLog"
# pnpm and Vite may print ordinary progress messages to stderr. Windows
# PowerShell 5 converts redirected native stderr into NativeCommandError when
# ErrorActionPreference is Stop. Merge both streams inside cmd.exe first so
# progress output is logged without being mistaken for a terminating error.
& cmd.exe /d /s /c "call pnpm build 2>&1" | Tee-Object -FilePath $BuildLog
$buildExitCode = $LASTEXITCODE
if ($buildExitCode -ne 0) { throw "Production build failed with code $buildExitCode. Send windows-build.log for diagnosis." }
if (-not (Test-Path (Join-Path $ProjectDir "dist"))) { throw "Build completed without creating the dist folder." }

Write-Step "Starting the production website"
$serviceCommand = "title Digital Artifact Site Service - KEEP OPEN && call pnpm start"
Start-Process -FilePath "cmd.exe" -ArgumentList "/k", $serviceCommand -WorkingDirectory $ProjectDir

for ($second = 1; $second -le 90; $second++) {
    Start-Sleep -Seconds 1
    if (Test-Site) {
        Write-Host ""
        Write-Host "Deployment succeeded: $SiteUrl" -ForegroundColor Green
        Write-Host "Keep the service window open while using the website."
        Start-Process $SiteUrl
        exit 0
    }
}

throw "The service did not respond within 90 seconds. Check the service window for the actual error."
