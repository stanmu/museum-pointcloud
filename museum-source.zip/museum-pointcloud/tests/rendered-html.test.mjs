import assert from "node:assert/strict";
import { access } from "node:fs/promises";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);
  return worker.fetch(
    new Request("http://localhost/", { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("renders the digital artifact experience", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /近代沈正镐脱胎竹根瓶/);
  assert.match(html, /朱漆菊瓣盖碗/);
  assert.match(html, /脱胎荷叶瓶/);
  assert.match(html, /脱胎提篮观音/);
  assert.match(html, /福建省文化和旅游厅/);
  assert.match(html, /数字文物研究室/);
  assert.match(html, /光影鉴赏/);
  assert.match(html, /资料来源/);
  assert.match(html, /关联事件/);
  assert.doesNotMatch(html, /codex-preview|react-loading-skeleton/);
  await Promise.all([1, 2, 3, 4].flatMap((index) => [
    access(new URL(`../public/artifact-0${index}.bin`, import.meta.url)),
    access(new URL(`../public/artifact-0${index}-fallback.png`, import.meta.url)),
    access(new URL(`../public/artifact-0${index}-solid.png`, import.meta.url)),
    access(new URL(`../public/artifact-0${index}-solid-v2.png`, import.meta.url)),
    access(new URL(`../public/artifact-0${index}-surface.bin`, import.meta.url)),
    access(new URL(`../public/artifact-0${index}-approved.png`, import.meta.url)),
  ]));
  await access(new URL("../public/museum-landscape-bg.png", import.meta.url));
  await access(new URL("../public/og.png", import.meta.url));
});
